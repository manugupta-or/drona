<?php
//index.php

$error = '';
$rating1 = '';
$rating2 = '';
$rating3 = '';
$rating4 = '';
$rating5 = '';
$rating6 = '';
$rating7 = '';
$rating8 = '';
$rating9 = '';
$rating10 = '';
$rating11 = '';
$rating12 = '';
$rating13 = '';
$rating14 = '';
$rating15 = '';
$rating16 = '';
$rating17 = '';
$rating18 = '';
$rating19 = '';
$rating20 = '';
$timestamp = '';

function clean_text($string)
{
 $string = trim($string);
 $string = stripslashes($string);
 $string = htmlspecialchars($string);
 return $string;
}

if(isset($_POST["submit"]))
{
 if(empty($_POST["rating1"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 1 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating1 = clean_text($_POST["rating1"]);
 }

 if(empty($_POST["rating2"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 2 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating2 = clean_text($_POST["rating2"]);
 }

 if(empty($_POST["rating3"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 1 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating3 = clean_text($_POST["rating3"]);
 }

 if(empty($_POST["rating4"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 2 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating4 = clean_text($_POST["rating4"]);
 }

 if(empty($_POST["rating5"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 1 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating5 = clean_text($_POST["rating5"]);
 }

 if(empty($_POST["rating6"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 2 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating6 = clean_text($_POST["rating6"]);
 }


 if(empty($_POST["rating7"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 1 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating7 = clean_text($_POST["rating7"]);
 }

 if(empty($_POST["rating8"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 2 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating8 = clean_text($_POST["rating8"]);
 }


 if(empty($_POST["rating9"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 1 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating9 = clean_text($_POST["rating9"]);
 }

 if(empty($_POST["rating10"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 2 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating10 = clean_text($_POST["rating10"]);
 }

 if(empty($_POST["rating11"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 1 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating11 = clean_text($_POST["rating11"]);
 }

  if(empty($_POST["rating12"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 2 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating12 = clean_text($_POST["rating12"]);
 }


 if(empty($_POST["rating13"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 1 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating13 = clean_text($_POST["rating13"]);
 }

  if(empty($_POST["rating14"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 2 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating14 = clean_text($_POST["rating14"]);
 }

 if(empty($_POST["rating15"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 1 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating15 = clean_text($_POST["rating15"]);
 }

  if(empty($_POST["rating16"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 2 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating16 = clean_text($_POST["rating16"]);
 }

 if(empty($_POST["rating17"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 1 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating17 = clean_text($_POST["rating17"]);
 }

  if(empty($_POST["rating18"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 2 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating18 = clean_text($_POST["rating18"]);
 }


 if(empty($_POST["rating19"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 1 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating19 = clean_text($_POST["rating19"]);
 }

  if(empty($_POST["rating20"]))
 {
  $error .= '<p><label class="text-danger">Rating of Bot 2 is missed somewhere. It should be selected</label></p>';
 }
 else
 {
  $rating20 = clean_text($_POST["rating20"]);
 }

 if($error == '')
 {
  $file_open = fopen("contact_data.csv", "a");
  $timestamp = time();
  date_default_timezone_set("Asia/Kolkata"); 
  $timestamp = date("d-m-Y h:i:sa", $timestamp); 

  