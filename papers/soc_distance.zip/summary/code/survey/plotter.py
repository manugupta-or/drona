import matplotlib.pyplot as plt
import numpy as np
import csv, os, sys

INPUT_FILE = sys.argv[1]
noOfQuestion = 7

# Q is containg the no of Yes,No and Maybe response for all the Question by all the people.
# Q[i][j] is total response for (i+1)-th Question for Yes(if j=0), No(if j=1) and Maybe(if j=2)
Q = [[0, 0, 0] for _ in range(noOfQuestion)]

with open(INPUT_FILE, 'r') as csvfile:
	reader = csv.reader(csvfile, delimiter=',')
	next(reader)
	for row in reader:
		for q_no in range(noOfQuestion):
			if row[q_no+1] == 'Yes':
				Q[q_no][0] += 1
			elif row[q_no+1] == 'Maybe':
				Q[q_no][1] += 1
			elif row[q_no+1] == 'No':
				Q[q_no][2] += 1
			else:
				sys.exit("Response code not in {'Yes', 'No', 'Maybe'}")

y_list = []
m_list = []
n_list = []

for i in range(len(Q)):
	noOfPeople_i = sum(Q[i])
	y_list.append(Q[i][0]/noOfPeople_i*100)
	m_list.append(Q[i][1]/noOfPeople_i*100)
	n_list.append(Q[i][2]/noOfPeople_i*100)

X = np.array(range(1,noOfQuestion+1))
y_list = np.array(y_list)
m_list = np.array(m_list)
n_list = np.array(n_list)

fig, ax = plt.subplots(figsize=(9,4))

ax.bar(X - 0.25, y_list ,color = 'green', width = 0.25, label ='Yes', capsize=1)
ax.bar(X + 0.00, m_list ,color = 'orange', width = 0.25, label ='Maybe', capsize=1)
ax.bar(X + 0.25, n_list ,color = 'red', width = 0.25, label ='No', capsize=1)

ax.grid()
ax.legend()
ax.set_xlabel('Survey questions')
ax.set_ylabel('Percentage')
plt.xticks(X)
# plt.show()

fig.savefig(os.path.join(os.getcwd(), 'Survey_report.pdf'))