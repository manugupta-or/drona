import numpy as np
from gurobipy import *
import random, re, os, time, sys, csv
import multiprocessing as mp
import concurrent.futures
import matplotlib.pyplot as plt

def print_sol(model):
    for var in model.getVars():
        if(abs(var.x)>1e-6):
            print('{0}:{1}'.format(var.varName,var.x))
            
    print('Allocation score :{0}'.format(model.objVal))
    return None


def optimizer(urgencyList,priority_MATRIX,N_agents, M, delta, slot_cap, tempAvgUrgent, tempAvgMid, tempAvgNoturgent, LOWER_URGENCY, MID_URGENCY, HIGHER_URGENCY):
        combinations,ms = multidict({
            (y,x):(delta**(priority_MATRIX[y-1][x-1]-1)) * urgencyList[y-1] for x in range(1,len(M)+1) for y in range(1,len(N_agents)+1)
            })
        valuation_matrix = ms.copy()
        
        model = Model('allocator')
        variables = model.addVars(combinations,lb=0,vtype=GRB.BINARY,name='assign')
        model.update()
        slots = model.addConstrs((variables.sum('*',j)<=slot_cap for j in M),'slots')
        agents = model.addConstrs((variables.sum(i,'*')<=1 for i in N_agents),'agents')
        model.setObjective(variables.prod(ms),GRB.MAXIMIZE)
        # model.write('mark0.lp')
        model.optimize()

        print("Model Status "+str(model.Status))
        print("===Optimal Allotment===")
        print_sol(model)
        allocation_map={}
        for var in model.getVars():
                assign = re.search(r"\[([A-Za-z,0-9_]+)\]", var.varName)
                assign = assign.group(1)
                assign = assign.split(',')
                if(abs(var.x)>1e-6):
                    
                    allocation_map[int(assign[0])]=int(assign[1])
                    
                    if(urgencyList[int(assign[0])-1]==LOWER_URGENCY):
                        tempAvgNoturgent.append(priority_MATRIX[int(assign[0])-1][int(assign[1])-1])
                    if(urgencyList[int(assign[0])-1]==MID_URGENCY):
                        tempAvgMid.append(priority_MATRIX[int(assign[0])-1][int(assign[1])-1])
                    if(urgencyList[int(assign[0])-1]==HIGHER_URGENCY):
                        tempAvgUrgent.append(priority_MATRIX[int(assign[0])-1][int(assign[1])-1])

        return valuation_matrix ,allocation_map , model.objVal


def perSampleCompute(argv):
    print("============================= iteration id:"+str(argv[0])+" ============================")
    tempAvgUrgent = []
    tempAvgMid = []
    tempAvgNoturgent = []

    tempTimeNoturgent = []
    tempTimeMedium = []
    tempTimeUrgent = []

    tempUtilityUrgent = []
    tempUtilityMedium = []
    tempUtilityNoturgent = []

    urgencylist = []
    
    for i in range(len(argv[1])):
        n = random.choice([argv[6],argv[7],argv[8]])
        urgencylist.append(n)
    
    valuation_matrix, allocation_map, valuation_sum = optimizer(urgencylist, argv[5], argv[1], argv[2], argv[4], argv[3], tempAvgUrgent, tempAvgMid, tempAvgNoturgent, argv[6], argv[7], argv[8])
    
    ############################# VCG #############################
    for index in range(1,len(argv[1])+1):
        if index in allocation_map: #there is chance agrent might not be allocated
            valuation_sum_agent = valuation_sum - valuation_matrix[(index, allocation_map[index])]
        else:
            continue
        urgency_of_agent = urgencylist[index-1]
        
        urgencylist_without_agent = urgencylist[:]
        priority_matrix_without_agent  = argv[5][:]
        N_without_agent =list(range(1, len(argv[1])))
        
        del urgencylist_without_agent[index-1]
        del priority_matrix_without_agent[index-1]

        valuation_matrix_without_agent , allocation_map_without_agent ,valuation_sum_without_agent = optimizer(urgencylist_without_agent, priority_matrix_without_agent, N_without_agent, argv[2], argv[4], argv[3],  tempAvgUrgent, tempAvgMid, tempAvgNoturgent, argv[6], argv[7], argv[8])

        VCG = valuation_sum_without_agent - valuation_sum_agent
        
        if(urgency_of_agent == argv[6]):
            tempTimeNoturgent.append(VCG)
            tempUtilityNoturgent.append(valuation_matrix[(index,allocation_map[index])]-VCG)
        elif(urgency_of_agent == argv[7]):
            tempTimeMedium.append(VCG)
            tempUtilityMedium.append(valuation_matrix[(index,allocation_map[index])]-VCG)
        elif(urgency_of_agent == argv[8]):
            tempTimeUrgent.append(VCG)
            tempUtilityUrgent.append(valuation_matrix[(index,allocation_map[index])]-VCG)

    ##############################################################
    
    # if iterated over a particular population size and for plotting avg_urgency(of that len(N) population) vs avg_slot 
    # alloted to each class.    
    # graph_obj.update({np.mean(urgencylist):(np.mean(tempAvgUrgent),np.std(tempAvgUrgent),
    #                                       np.mean(tempAvgMid),np.std(tempAvgMid),
    #                                      np.mean(tempAvgNoturgent),np.std(tempAvgNoturgent))})

    return tempTimeNoturgent, tempTimeMedium, tempTimeUrgent, tempAvgUrgent, tempAvgMid, tempAvgNoturgent, tempUtilityUrgent, tempUtilityMedium, tempUtilityNoturgent


def main():
    no_of_slots = int(sys.argv[1])
    percent_bound = int(sys.argv[3])

    LOWER_URGENCY = int(sys.argv[5])
    MID_URGENCY = int(sys.argv[6])
    HIGHER_URGENCY = int(sys.argv[7])

    repeat = int(sys.argv[9]) # for repeatation over each population for random preference normalization. if preference = 0 => repeat = 1
    preference = int(sys.argv[8]) # preference = 0 => common and preference = 1 , individual

    urgent = []
    stdUrgent = []
    medium = []
    stdMedium = []
    noturgent = []
    stdNoturgent = []
    avgUrgency = []
    graph_obj = dict()
    slotSize = []

    waitUrgent = []
    waitMedium = []
    waitNoturgent = []
    waitStdUrgent = []
    waitStdMedium = []
    waitStdNoturgent = []

    utilityUrgent = []
    utilityMedium = []
    utilityNoturgent = []
    stdUtilityUrgent = []
    stdUtilityMedium = []
    stdUtilityNoturgent = []

    delta = float(sys.argv[4])
    slot_cap= int(sys.argv[2]) 

    start = time.perf_counter()

    # Loop starts with k as iter. till MAX_POPULATION
    for l in range(2 , no_of_slots+1):
        M = list(range(1, l+1)) #number of slots
        MAX_POPULATION = int(len(M)*slot_cap + percent_bound*len(M)*slot_cap/100)
        k=MAX_POPULATION
        # If for a single k its been checked we can set MAX_POPULATION = MIN_POPULATION+1 in range
        # i.e. k = MAX_POPULATION and uncomment the desried code.
        N = list(range(1, k+1)) #population base : with range(1,k) with k as iterator till MAX_POPULATION

        # Denote temp. for population size vs slot iteration
        tempAvgUrgent_population = []
        tempAvgMid_population = []
        tempAvgNoturgent_population = []

        tempTimeUrgent = []
        tempTimeMedium = []
        tempTimeNoturgent = []
        
        tempUtilityUrgent = []
        tempUtilityMedium = []
        tempUtilityNoturgent = []

        rows, cols = (k, len(M)) 
        priority_matrix = []

        for _ in range(repeat):

            if preference == 1:
                for _ in range(rows):
                    priority_matrix.append(list(np.random.permutation(range(1,cols+1))))
            else:
                # FOR EQUAL PRIORITY FOR ALL PEOPLE
                priority_matrix = [[(i+1) for i in range(cols)] for j in range(rows)] 

            # iteration for each n. Taken as sample for each n
            with concurrent.futures.ProcessPoolExecutor() as executer:
                results = [executer.submit(perSampleCompute,[i, N, M, slot_cap, delta, priority_matrix, LOWER_URGENCY, MID_URGENCY, HIGHER_URGENCY]) for i in range(10*k)]
                
                for f in concurrent.futures.as_completed(results):
                    tempTimeNoturgent.extend(f.result()[0])
                    tempTimeMedium.extend(f.result()[1])
                    tempTimeUrgent.extend(f.result()[2])
                    tempAvgUrgent_population.extend(f.result()[3])
                    tempAvgMid_population.extend(f.result()[4])
                    tempAvgNoturgent_population.extend(f.result()[5])
                    tempUtilityUrgent.extend(f.result()[6])
                    tempUtilityMedium.extend(f.result()[7])
                    tempUtilityNoturgent.extend(f.result()[8])
        
        # If changing population no. this is needed to be kept uncommented else commented.
        urgent.append(np.mean(tempAvgUrgent_population))
        stdUrgent.append(np.std(tempAvgUrgent_population))
        medium.append(np.mean(tempAvgMid_population))
        stdMedium.append(np.std(tempAvgMid_population))
        noturgent.append(np.mean(tempAvgNoturgent_population))
        stdNoturgent.append(np.std(tempAvgNoturgent_population))
        slotSize.append(l)
        #Finding avg time from all samples:
        waitUrgent.append(np.mean(tempTimeUrgent))
        waitMedium.append(np.mean(tempTimeMedium))
        waitNoturgent.append(np.mean(tempTimeNoturgent))
        waitStdUrgent.append(np.std(tempTimeUrgent))
        waitStdMedium.append(np.std(tempTimeMedium))
        waitStdNoturgent.append(np.std(tempTimeNoturgent))
        #Find Utility
        utilityUrgent.append(np.mean(tempUtilityUrgent)) 
        utilityMedium.append(np.mean(tempUtilityMedium))
        utilityNoturgent.append(np.mean(tempUtilityNoturgent))
        stdUtilityUrgent.append(np.std(tempUtilityUrgent))
        stdUtilityMedium.append(np.std(tempUtilityMedium))
        stdUtilityNoturgent.append(np.std(tempUtilityNoturgent))

    end = time.perf_counter()

    print("\nMAX_SLOT_SIZE: "+str(no_of_slots))
    print(f'Time Taken for computation of {no_of_slots} Slots : {end-start} second(s)')

    waitNoturgent= np.array(waitNoturgent)
    waitMedium = np.array(waitMedium)
    waitUrgent = np.array(waitUrgent) 

    X = np.arange(2 , no_of_slots+1)
    fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True)
    ax1.set_title('Priority-Delay tradeoff')
    ax1.bar(X + 0.00, noturgent,yerr=stdNoturgent, color = 'green', width = 0.25,label ='Not-Urgent',capsize=1)
    ax1.bar(X + 0.25, medium,yerr=stdMedium , color = 'orange', width = 0.25,label ='Medium',capsize=1)
    ax1.bar(X + 0.50, urgent, yerr=stdUrgent ,color = 'dodgerblue', width = 0.25,label ='Urgent',capsize=1)
    ax1.set_ylabel('Allocated slot preference')
    ax1.legend(loc ='upper left') 
    ax1.grid()
    ax2.bar(X + 0.00, waitNoturgent,yerr=waitStdNoturgent, color = 'palegreen', width = 0.25,label ='Not-Urgent',capsize=1)
    ax2.bar(X + 0.25, waitMedium,yerr=waitStdMedium , color = 'moccasin', width = 0.25,label ='Medium',capsize=1)
    ax2.bar(X + 0.50, waitUrgent, yerr=waitStdUrgent,color = 'mediumturquoise', width = 0.25,label ='Urgent',capsize=1)
    ax2.set_ylabel('Delay')
    ax2.grid()
    ax2.legend(loc ='upper left') 
    plt.xlabel(r'slotSize, $n$')
    plt.xticks(X+0.25, X)
    plt.tight_layout()

    fig.savefig(os.path.join(os.getcwd(), 'output/plots/img32_1_'+str(no_of_slots)+"_"+str(MAX_POPULATION)+"_"+str(preference)))

    # For Wait time vs population
    # fig, ax = plt.subplots()
    # X = np.arange(2 ,no_of_slots+1)
    # ax.bar(X, waitNoturgent, width=0.25, yerr= waitStdNoturgent , label='Not-Urgent',color = 'green',capsize=3)
    # ax.bar(X, waitMedium , width=0.25, yerr= waitStdMedium , bottom=waitNoturgent,label ='Medium', color = 'orange',capsize=3)
    # ax.bar(X, waitUrgent , width=0.25, yerr= waitStdUrgent , bottom= waitMedium +waitNoturgent,label ='Urgent',color = 'dodgerblue',capsize=3)

    # ax.legend()

    # ax.set_xlabel('slotSize')
    # ax.set_ylabel('VCG Payment')
    # ax.set_title("Wait time vs slotSize")

    # fig.savefig(os.path.join(os.getcwd(), 'output/plots/img32_2_'+str(no_of_slots)+"_"+str(MAX_POPULATION)+"_"+str(preference)))

    fig, ax = plt.subplots()
    X = np.arange(2 ,no_of_slots+1)
    ax.bar(X + 0.00, utilityNoturgent ,yerr=stdUtilityUrgent, color = 'green', width = 0.25,label ='Not-Urgent',capsize=1)
    ax.bar(X + 0.25, utilityMedium ,yerr=stdUtilityMedium , color = 'orange', width = 0.25,label ='Medium',capsize=1)
    ax.bar(X + 0.50, utilityUrgent , yerr=stdUtilityNoturgent ,color = 'dodgerblue', width = 0.25,label ='Urgent',capsize=1)

    ax.legend()

    ax.set_xlabel('slotSize')
    ax.set_ylabel('Utility')
    ax.set_title("Utility vs slotSize")

    fig.savefig(os.path.join(os.getcwd(), 'output/plots/img32_3_'+str(no_of_slots)+"_"+str(MAX_POPULATION)+"_"+str(preference)))

    with open(os.path.join(os.getcwd(), 'output/csv/data32_'+str(len(M))+"_"+str(MAX_POPULATION)+"_"+str(preference)+".csv"), mode ='w') as csvfile:
        fieldName = ['slotSize','not_urgent', 'medium', 'urgent', 'stdNoturgent', 'stdMedium', 'stdUrgent',
        'waitNoturgent','waitMedium', 'waitUrgent', 'waitStdNoturgent', 'waitStdMedium', 'waitStdUrgent',
        'utilityUrgent', 'utilityMedium','utilityNoturgent', 'stdUtilityUrgent', 'stdUtilityMedium', 'stdUtilityNoturgent']
        writer = csv.DictWriter(csvfile, fieldnames = fieldName)

        writer.writeheader()
        for i in range(len(X)):
            writer.writerow({
                'slotSize' : X[i], 
                'not_urgent': noturgent[i], 
                'medium': medium[i], 
                'urgent': urgent[i], 
                'stdNoturgent': stdNoturgent[i], 
                'stdMedium': stdMedium[i], 
                'stdUrgent': stdUrgent[i],
                'waitNoturgent' : waitNoturgent[i],
                'waitMedium' : waitMedium[i],
                'waitUrgent' : waitStdUrgent[i],
                'waitStdNoturgent' : waitStdNoturgent[i],
                'waitStdMedium' : waitStdMedium[i],
                'waitStdUrgent' : waitStdUrgent[i],
                'utilityUrgent' : utilityUrgent[i],
                'utilityMedium' : utilityMedium[i],
                'utilityNoturgent' : utilityNoturgent[i],
                'stdUtilityUrgent' : stdUtilityUrgent[i],
                'stdUtilityMedium' : stdUtilityMedium[i],
                'stdUtilityNoturgent' : stdUtilityNoturgent[i]
                })

if __name__ == '__main__':
    main()