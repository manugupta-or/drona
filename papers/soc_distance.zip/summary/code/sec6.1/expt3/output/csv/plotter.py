import matplotlib.pyplot as plt
import numpy as np
import csv, os, sys

INPUT_FILE = sys.argv[1]

populationSize = []
noturgent = []
medium = []
urgent = []
stdNoturgent = []
stdMedium = []
stdUrgent = []
waitNoturgent = [] 
waitMedium = []
waitUrgent = []
waitStdNoturgent = []
waitStdMedium = []
waitStdUrgent = []
utilityUrgent = []
utilityMedium = []
utilityNoturgent = []
stdUtilityUrgent = []
stdUtilityMedium = []
stdUtilityNoturgent = []

with open(INPUT_FILE, 'r') as csvfile:
	reader = csv.reader(csvfile, delimiter=',')
	next(reader)
	for rows in reader:
		populationSize.append(float(rows[0]))
		noturgent.append(float(rows[1]))
		medium.append(float(rows[2]))
		urgent.append(float(rows[3]))
		stdNoturgent.append(float(rows[4]))
		stdMedium.append(float(rows[5]))
		stdUrgent.append(float(rows[6]))
		waitNoturgent.append(float(rows[7])) 
		waitMedium.append(float(rows[8]))
		waitUrgent.append(float(rows[9]))
		waitStdNoturgent.append(float(rows[10]))
		waitStdMedium.append(float(rows[11]))
		waitStdUrgent.append(float(rows[12]))
		utilityUrgent.append(float(rows[13]))
		utilityMedium.append(float(rows[14]))
		utilityNoturgent.append(float(rows[15]))
		stdUtilityUrgent.append(float(rows[16]))
		stdUtilityMedium.append(float(rows[17]))
		stdUtilityNoturgent.append(float(rows[18]))

fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True)
X = np.array(populationSize)
ax1.set_title('Priority-Delay tradeoff')
ax1.bar(X + 0.00, noturgent,yerr=stdNoturgent, color = 'green', width = 0.25,label ='Not-Urgent',capsize=1)
ax1.bar(X + 0.25, medium,yerr=stdMedium , color = 'orange', width = 0.25,label ='Medium',capsize=1)
ax1.bar(X + 0.50, urgent, yerr=stdUrgent ,color = 'dodgerblue', width = 0.25,label ='Urgent',capsize=1)
ax1.set_ylabel('Allocated slot preference')
ax1.legend(loc ='upper left') 
ax1.grid()
ax2.bar(X + 0.00, waitNoturgent,yerr=waitStdNoturgent, color = 'palegreen', width = 0.25,label ='Not-Urgent',capsize=1)
ax2.bar(X + 0.25, waitMedium,yerr=waitStdMedium, color = 'moccasin', width = 0.25,label ='Medium',capsize=1)
ax2.bar(X + 0.50, waitUrgent, yerr=waitStdUrgent, color = 'mediumturquoise', width = 0.25,label ='Urgent',capsize=1)
ax2.set_ylabel('Delay')
ax2.grid()
ax2.legend(loc ='upper left') 

if INPUT_FILE[5] == '2':
	plt.xlabel(r'slotSize, $n$')
else:	
	plt.xlabel(r'Population, $n$')

plt.xticks(X+0.25, X)
plt.tight_layout()

plt.show()

# For Wait time vs population
# fig, ax = plt.subplots()
# ax.bar(X, waitNoturgent, width=0.25, yerr= waitStdNoturgent , label='Not-Urgent',color = 'green',capsize=3)
# ax.bar(X, waitMedium , width=0.25, yerr= waitStdMedium , bottom=waitNoturgent,label ='Medium', color = 'orange',capsize=3)
# ax.bar(X, waitUrgent , width=0.25, yerr= waitStdUrgent , bottom= waitMedium +waitNoturgent,label ='Urgent',color = 'dodgerblue',capsize=3)

# ax.legend()

# ax.set_xlabel('populationSize')
# ax.set_ylabel('VCG Payment')
# ax.set_title("Wait time vs populationSize")

# plt.show()

fig, ax = plt.subplots()
ax.bar(X + 0.00, utilityNoturgent ,yerr=stdUtilityUrgent, color = 'green', width = 0.25,label ='Not-Urgent',capsize=1)
ax.bar(X + 0.25, utilityMedium ,yerr=stdUtilityMedium , color = 'orange', width = 0.25,label ='Medium',capsize=1)
ax.bar(X + 0.50, utilityUrgent , yerr=stdUtilityNoturgent ,color = 'dodgerblue', width = 0.25,label ='Urgent',capsize=1)

ax.legend()


ax.set_ylabel('Utility')
if INPUT_FILE[5] == '2':
	ax.set_xlabel('slotSize')
	ax.set_title("Utility vs slotSize")
else:	
	ax.set_xlabel('populationSize')
	ax.set_title("Utility vs populationSize")
plt.show()