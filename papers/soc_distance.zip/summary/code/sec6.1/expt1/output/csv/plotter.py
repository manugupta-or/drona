import matplotlib.pyplot as plt
import csv, os, sys

INPUT_FILE = sys.argv[1]

avgUrgency = []
not_urgent = []
medium = []
urgent = []
stdNoturgent = []
stdMedium = []
stdUrgent = []

with open(INPUT_FILE, 'r') as csvfile:
	reader = csv.reader(csvfile, delimiter=',')
	next(reader)
	for rows in reader:
		avgUrgency.append(float(rows[0]))
		not_urgent.append(float(rows[1]))
		medium.append(float(rows[2]))
		urgent.append(float(rows[3]))
		stdNoturgent.append(float(rows[4]))
		stdMedium.append(float(rows[5]))
		stdUrgent.append(float(rows[6]))

fig = plt.figure(figsize=(20,10) ) 
x = avgUrgency 
plt.errorbar(x,urgent, yerr = stdUrgent,   uplims = True,  
             lolims = True, 
             label ='Urgent') 

plt.errorbar(x,medium, yerr = stdMedium,   uplims = True,  
             lolims = True, 
             label ='Medium')  

plt.errorbar(x,not_urgent, yerr = stdNoturgent,   uplims = True,  
             lolims = True, 
             label ='Not-Urgent') 

plt.legend(loc ='lower right') 

plt.xlabel('Average Urgency')
plt.ylabel('Slots')
plt.title('Average Alloted Slot vs Average Urgency') 
plt.grid()
plt.show()