import numpy as np
from gurobipy import *
import random, sys, os
import re, csv
import matplotlib.pyplot as plt 

def print_sol(model):
    for var in model.getVars():
        if(abs(var.x)>1e-6):
            print('{0}:{1}'.format(var.varName,var.x))
            
    print('Allocation score :{0}'.format(model.objVal))
    return None

def print_corr(model,priority_matrix,urgency):
    print("====ALLOCATION TO PREFRENCE CORRELATIION====")
    for var in model.getVars():
        assign = re.search(r"\[([A-Za-z,0-9_]+)\]", var.varName)
        assign = assign.group(1)
        assign = assign.split(',')

        if(abs(var.x)>1e-6):
            # For Slot and preference comparision
            print("Agent id: "+ str(assign[0]) + " :: ( Alloted Slot : "+ str(assign[1]) + ") , ( Preffered Slot : "+str(priority_matrix[int(assign[0])-1])+" ) , ( Urgency : "+str(urgency[int(assign[0])-1])+" )")

def main():
    no_of_slots = int(sys.argv[1])
    percent_bound = int(sys.argv[3])

    LOWER_URGENCY = int(sys.argv[5])
    MID_URGENCY = int(sys.argv[6])
    HIGHER_URGENCY = int(sys.argv[7])

    M = list(range(1, no_of_slots+1)) #number of slots

    urgent=[]
    stdUrgent=[]
    medium=[]
    stdMedium=[]
    noturgent=[]
    stdNoturgent=[]
    avgUrgency=[]
    graph_obj = dict()
    populationSize = []

    delta = float(sys.argv[4])
    slot_cap= int(sys.argv[2]) 

    MAX_POPULATION = int(len(M)*slot_cap + percent_bound*len(M)*slot_cap/100) 
    print(MAX_POPULATION)

    # Loop starts with k as iter. till MAX_POPULATION
    for k in range(MAX_POPULATION,MAX_POPULATION+1):
        # If for a single k its been checked we can set MAX_POPULATION = MIN_POPULATION+1 in range
        # i.e. k = MAX_POPULATION and uncomment the desried code.
        N = list(range(1, k))#population base : with range(1,k) with k as iterator till MAX_POPULATION
        iteration = 0

        # Denote temp. for population size vs slot iteration
        tempAvgUrgent_population=[]
        tempAvgMid_population=[]
        tempAvgNoturgent_population=[]

        rows, cols = (len(N), len(M)) 
        priority_matrix = []
        # priority_matrix = [[(i+1) for i in range(cols)] for j in range(rows)]
        for _ in range(10):
            for _ in range(rows):
                priority_matrix.append(list(np.random.permutation(range(1,cols+1))))
            
            print("PRIORITY MATRIX:")
            print(priority_matrix)

            while(iteration<10*k): # iteration for each n. Taken as sample for each n
                tempAvgUrgent=[]
                tempAvgMid=[]
                tempAvgNoturgent=[]
                print("============================= iteration id:"+str(iteration)+"============================")
                urgencylist = []
                for i in range(len(N)):
                    n = random.choice([LOWER_URGENCY,MID_URGENCY,HIGHER_URGENCY])
                    urgencylist.append(n)
                #urgencylist = [3,3,3,3,3,3,3,3,3]  #just to assign manually

                combinations,ms = multidict({
                    (y,x):(delta**priority_matrix[y-1][x-1]) * urgencylist[y-1] for x in range(1,len(M)+1) for y in range(1,len(N)+1)
                    })

                model = Model('allocator')
                variables = model.addVars(combinations,lb=0,vtype=GRB.BINARY,name='assign')
                model.update()
                slots = model.addConstrs((variables.sum('*',j)<=slot_cap for j in M),'slots')
                agents = model.addConstrs((variables.sum(i,'*')<=1 for i in N),'agents')
                model.setObjective(variables.prod(ms),GRB.MAXIMIZE)
                model.write('mark0.lp')
                model.optimize()

                print("Model Status "+str(model.Status))
                print("===Optimal Allotment===")
                print_sol(model)

                print_corr(model,priority_matrix,urgencylist)
                for var in model.getVars():
                        assign = re.search(r"\[([A-Za-z,0-9_]+)\]", var.varName)
                        assign = assign.group(1)
                        assign = assign.split(',')
                        
                        if(abs(var.x)>1e-6):
                            if(urgencylist[int(assign[0])-1]==LOWER_URGENCY):
                                tempAvgNoturgent.append(priority_matrix[int(assign[0])-1][int(assign[1])-1])
                                tempAvgNoturgent_population.append(priority_matrix[int(assign[0])-1][int(assign[1])-1])
                            if(urgencylist[int(assign[0])-1]==MID_URGENCY):
                                tempAvgMid.append(priority_matrix[int(assign[0])-1][int(assign[1])-1])
                                tempAvgMid_population.append(priority_matrix[int(assign[0])-1][int(assign[1])-1])
                            if(urgencylist[int(assign[0])-1]==HIGHER_URGENCY):
                                tempAvgUrgent.append(priority_matrix[int(assign[0])-1][int(assign[1])-1])
                                tempAvgUrgent_population.append(priority_matrix[int(assign[0])-1][int(assign[1])-1])

                # if iterated over a particular population size and for plotting avg_urgency(of that len(N) population) vs avg_slot 
                # alloted to each class.    
                graph_obj.update({np.mean(urgencylist):(np.mean(tempAvgUrgent),np.std(tempAvgUrgent),
                                                      np.mean(tempAvgMid),np.std(tempAvgMid),
                                                     np.mean(tempAvgNoturgent),np.std(tempAvgNoturgent))})
                print("\n\n")
                iteration+=1


        # If changing population no. this is needed to be kept uncommented else commented.
    #     urgent.append(np.mean(tempAvgUrgent_population))
    #     stdUrgent.append(np.std(tempAvgUrgent_population))
    #     medium.append(np.mean(tempAvgMid_population))
    #     stdMedium.append(np.std(tempAvgMid_population))
    #     noturgent.append(np.mean(tempAvgNoturgent_population))
    #     stdNoturgent.append(np.std(tempAvgNoturgent_population))
    #     populationSize.append(k)

    # For Loop ends for population

    ###### Below code is for single N with avg. urgency vs avg. slot alloted for 10*N samples 
    ###### Needed to be commented for population vs slot pref.
    graph_x=sorted(graph_obj)

    for key in graph_x:
        value = graph_obj[key]
        urgent.append(value[0])
        stdUrgent.append(value[1])
        medium.append(value[2])
        stdMedium.append(value[3])
        noturgent.append(value[4])
        stdNoturgent.append(value[5])
        avgUrgency.append(key)
    ###########################################

    ##### TO BE REMOVED FROM COMMENT IF AVG. URGENCY VS SLOTS
    fig = plt.figure(figsize=(20,10) )
    x = avgUrgency 
    plt.errorbar(x,urgent, yerr = stdUrgent,   uplims = True,  
                 lolims = True, 
                 label ='Urgent') 

    plt.errorbar(x,medium, yerr = stdMedium,   uplims = True,  
                 lolims = True, 
                 label ='Medium')  

    plt.errorbar(x,noturgent, yerr = stdNoturgent,   uplims = True,  
                 lolims = True, 
                 label ='Not-Urgent') 

    plt.legend(loc ='lower right') 
    plt.xlabel('Average Urgency')
    plt.ylabel('Slots Prefference')
    plt.title('Average Prefference of Alloted slot Slot vs Average Urgency') 
    plt.grid()
    fig.savefig(os.path.join(os.getcwd(), 'output/plots/img1b_'+str(no_of_slots)+"_"+str(MAX_POPULATION)))

    with open(os.path.join(os.getcwd(), 'output/csv/data1b_'+str(len(M))+"_"+str(MAX_POPULATION)+".csv"), mode ='w') as csvfile:
        fieldName = ['averageUrgency','not_urgent', 'medium', 'urgent', 'stdNoturgent', 'stdMedium', 'stdUrgent']
        writer = csv.DictWriter(csvfile, fieldnames = fieldName)

        writer.writeheader()
        for i in range(len(x)):
            writer.writerow({
                'averageUrgency' : x[i], 
                'not_urgent': noturgent[i], 
                'medium': medium[i], 
                'urgent': urgent[i], 
                'stdNoturgent': stdNoturgent[i], 
                'stdMedium': stdMedium[i], 
                'stdUrgent': stdUrgent[i]
                })

if __name__ == '__main__':
    main()