import numpy as np
from gurobipy import *
import random, re, os, time, sys, csv
import multiprocessing as mp
import concurrent.futures
import matplotlib.pyplot as plt 

def print_sol(model):
    for var in model.getVars():
        if(abs(var.x)>1e-6):
            print('{0}:{1}'.format(var.varName,var.x))
            
    print('Allocation score :{0}'.format(model.objVal))
    return None

def perSampleCompute(argv): # iteration for each n. Taken as sample for each n
        print("============================= iteration id:"+str(argv[0])+"============================\n\n")
        tempAvgNoturgent_population_func=[]
        tempAvgMid_population_func=[]
        tempAvgUrgent_population_func=[]
        
        urgencylist = []
        for i in range(len(argv[1])):
            n = random.choice([argv[5],argv[6],argv[7]])
            urgencylist.append(n)
        #urgencylist = [3,3,3,3,3,3,3,3,3]  #just to assign manually

        combinations,ms = multidict({
            (y,x):(argv[4]**argv[8][y-1][x-1]) * urgencylist[y-1] for x in range(1,len(argv[2])+1) for y in range(1,len(argv[1])+1)
            })

        model = Model('allocator')
        variables = model.addVars(combinations,lb=0,vtype=GRB.BINARY,name='assign')
        model.update()
        slots = model.addConstrs((variables.sum('*',j)<=argv[3] for j in argv[2]),'slots')
        agents = model.addConstrs((variables.sum(i,'*')<=1 for i in argv[1]),'agents')
        model.setObjective(variables.prod(ms),GRB.MAXIMIZE)
        model.write('mark0.lp')
        model.optimize()

        print("Model Status "+str(model.Status))
        print("===Optimal Allotment===")
        print_sol(model)

        for var in model.getVars():
                assign = re.search(r"\[([A-Za-z,0-9_]+)\]", var.varName)
                assign = assign.group(1)
                assign = assign.split(',')
                if(abs(var.x)>1e-6):
                    if(urgencylist[int(assign[0])-1]==argv[5]):
                        tempAvgNoturgent_population_func.append(argv[8][int(assign[0])-1][int(assign[1])-1])
                    if(urgencylist[int(assign[0])-1]==argv[6]):
                        tempAvgMid_population_func.append(argv[8][int(assign[0])-1][int(assign[1])-1])
                    if(urgencylist[int(assign[0])-1]==argv[7]):
                        tempAvgUrgent_population_func.append(argv[8][int(assign[0])-1][int(assign[1])-1])

        # if iterated over a particular population size and for plotting avg_urgency(of that len(N) population) vs avg_slot 
        # alloted to each class.    
        # graph_obj.update({np.mean(urgencylist):(np.mean(tempAvgUrgent),np.std(tempAvgUrgent),
        #                                       np.mean(tempAvgMid),np.std(tempAvgMid),
        #                                      np.mean(tempAvgNoturgent),np.std(tempAvgNoturgent))})
        return (tempAvgNoturgent_population_func, tempAvgMid_population_func, tempAvgUrgent_population_func)
        # print("\n\n")

def main():
    no_of_slots = int(sys.argv[1])
    percent_bound = int(sys.argv[3])

    LOWER_URGENCY = int(sys.argv[5])
    MID_URGENCY = int(sys.argv[6])
    HIGHER_URGENCY = int(sys.argv[7])

    repeat = int(sys.argv[9]) # for repeatation over each population for random preference normalization. if preference = 0 => repeat = 1
    preference = int(sys.argv[8]) # preference = 0 => common and preference = 1 , individual

    M = list(range(1, no_of_slots+1)) #number of slots

    urgent=[]
    stdUrgent=[]
    medium=[]
    stdMedium=[]
    noturgent=[]
    stdNoturgent=[]
    avgUrgency=[]
    graph_obj = dict()
    populationSize = []

    delta = float(sys.argv[4])
    slot_cap= int(sys.argv[2])

    MAX_POPULATION = int(len(M)*slot_cap + percent_bound*len(M)*slot_cap/100) 

    start = time.perf_counter()

    # Loop starts with k as iter. till MAX_POPULATION
    for k in range(2,MAX_POPULATION+1):
        # If for a single k its been checked we can set MAX_POPULATION = MIN_POPULATION+1 in range
        # i.e. k = MAX_POPULATION and uncomment the desried code.
        N = list(range(1, k+1))#population base : with range(1,k) with k as iterator till MAX_POPULATION

        # Denote temp. for population size vs slot iteration
        tempAvgUrgent_population=[]
        tempAvgMid_population=[]
        tempAvgNoturgent_population=[]

        rows, cols = (len(N), len(M)) 
        
        # To use random preference matrix it reffered to use a sampling over these too for normalization of randomness.
        # DONT FORGET TO INDENT
        # To Do so add a loop for the below code between !! LOOP START-END RANDOM PREFERENCE !!
        # The above constant preference can also be put in this loop WLOG.
        # !! LOOP START !! 
        for _ in range(repeat):
            priority_matrix = []
            
            if preference == 1:
                for i in range(rows):
                    priority_matrix.append(list(np.random.permutation(range(1,cols+1))))
            else:
                priority_matrix = [[(i+1) for i in range(cols)] for j in range(rows)]

            print("PRIORITY MATRIX:")
            print(priority_matrix)

            with concurrent.futures.ProcessPoolExecutor() as executer:
                results = [executer.submit(perSampleCompute,[i, N, M, slot_cap, delta, LOWER_URGENCY, MID_URGENCY, HIGHER_URGENCY,priority_matrix]) for i in range(10*k)]
                
                for f in concurrent.futures.as_completed(results):
                    tempAvgUrgent_population.extend(f.result()[2])
                    tempAvgMid_population.extend(f.result()[1])
                    tempAvgNoturgent_population.extend(f.result()[0])
        # !! LOOP END !!
        
        # If changing population no. this is needed to be kept uncommented else commented.
        urgent.append(np.mean(tempAvgUrgent_population))
        stdUrgent.append(np.std(tempAvgUrgent_population))
        medium.append(np.mean(tempAvgMid_population))
        stdMedium.append(np.std(tempAvgMid_population))
        noturgent.append(np.mean(tempAvgNoturgent_population))
        stdNoturgent.append(np.std(tempAvgNoturgent_population))
        populationSize.append(k)

    # For Loop ends for population

    end = time.perf_counter()

    print("MAX_POPULATION: "+str(MAX_POPULATION))
    print(f'Time Taken for computation of {MAX_POPULATION} : {end-start} second(s)')

    fig = plt.figure(figsize=(20,10) )
    x = np.array(populationSize)
    urgent = np.array(urgent)
    medium = np.array(medium)
    noturgent =np.array(noturgent)
    stdUrgent=np.array(stdUrgent)
    stdMedium=np.array(stdMedium)
    stdNoturgent=np.array(stdNoturgent)
    plt.plot(x, urgent,'-',color='dodgerblue',label ='Urgent')
    plt.fill_between(x, urgent - stdUrgent, urgent + stdUrgent,color='dodgerblue', alpha=0.3)
    plt.plot(x,medium,'-',color ='orange',label ='Medium')
    plt.fill_between(x, medium - stdMedium, medium + stdMedium,color='orange', alpha=0.3)
    plt.plot(x,noturgent,'-',color='green',label ='Not-Urgent')
    plt.fill_between(x, noturgent - stdNoturgent, noturgent + stdNoturgent,color='lime', alpha=0.2)

    plt.xlabel('population')
    plt.ylabel('slots')
    plt.title('population vs preffered slots')
    plt.legend(loc ='upper left') 
    plt.grid()
    fig.savefig(os.path.join(os.getcwd(), 'output/plots/img_'+str(len(M))+"_"+str(MAX_POPULATION)+"_"+str(preference)))
    
    with open(os.path.join(os.getcwd(), 'output/csv/data_'+str(len(M))+"_"+str(MAX_POPULATION)+"_"+str(preference)+".csv"), mode ='w') as csvfile:
        fieldName = ['populationSize','not_urgent', 'medium', 'urgent', 'stdNoturgent', 'stdMedium', 'stdUrgent']
        writer = csv.DictWriter(csvfile, fieldnames = fieldName)

        writer.writeheader()
        for i in range(len(x)):
            writer.writerow({
                'populationSize' : x[i], 
                'not_urgent': noturgent[i], 
                'medium': medium[i], 
                'urgent': urgent[i], 
                'stdNoturgent': stdNoturgent[i], 
                'stdMedium': stdMedium[i], 
                'stdUrgent': stdUrgent[i]
                })


if __name__ == '__main__':
    main()