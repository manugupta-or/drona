import matplotlib.pyplot as plt
import numpy as np
import csv, os, sys

INPUT_FILE1 = sys.argv[1]

populationSize1 = []
not_urgent1 = []
medium1 = []
urgent1 = []
stdNoturgent1 = []
stdMedium1 = []
stdUrgent1 = []

INPUT_FILE2 = sys.argv[2]

populationSize2 = []
not_urgent2 = []
medium2 = []
urgent2 = []
stdNoturgent2 = []
stdMedium2 = []
stdUrgent2 = []

with open(INPUT_FILE1, 'r') as csvfile:
	reader = csv.reader(csvfile, delimiter=',')
	next(reader)
	for rows in reader:
		populationSize1.append(float(rows[0]))
		not_urgent1.append(float(rows[1]))
		medium1.append(float(rows[2]))
		urgent1.append(float(rows[3]))
		stdNoturgent1.append(float(rows[4]))
		stdMedium1.append(float(rows[5]))
		stdUrgent1.append(float(rows[6]))

with open(INPUT_FILE2, 'r') as csvfile:
	reader = csv.reader(csvfile, delimiter=',')
	next(reader)
	for rows in reader:
		populationSize2.append(float(rows[0]))
		not_urgent2.append(float(rows[1]))
		medium2.append(float(rows[2]))
		urgent2.append(float(rows[3]))
		stdNoturgent2.append(float(rows[4]))
		stdMedium2.append(float(rows[5]))
		stdUrgent2.append(float(rows[6]))


fig, (ax1,ax2) = plt.subplots(2, 1, sharex=True, figsize=(12,8))
x1 = np.array(populationSize1)
urgent1 = np.array(urgent1)
medium1 = np.array(medium1)
not_urgent1 = np.array(not_urgent1)
stdUrgent1 = np.array(stdUrgent1)
stdMedium1 = np.array(stdMedium1)
stdNoturgent1 = np.array(stdNoturgent1)
ax1.plot(x1, urgent1,'-',color='dodgerblue',label ='Urgent')
ax1.fill_between(x1, urgent1 - stdUrgent1, urgent1 + stdUrgent1,color='dodgerblue', alpha=0.3)
ax1.plot(x1,medium1,'-',color ='orange',label ='Medium')
ax1.fill_between(x1, medium1 - stdMedium1, medium1 + stdMedium1,color='orange', alpha=0.3)
ax1.plot(x1,not_urgent1,'-',color='green',label ='Not-Urgent')
ax1.fill_between(x1, not_urgent1 - stdNoturgent1, not_urgent1 + stdNoturgent1,color='lime', alpha=0.2)

ax1.set_ylabel('Allocated slot preference')
# plt.title('population vs preffered slots')
ax1.legend(loc ='upper left') 
ax1.grid()

x2 = np.array(populationSize2)
urgent2 = np.array(urgent2)
medium2 = np.array(medium2)
not_urgent2 = np.array(not_urgent2)
stdUrgent2 = np.array(stdUrgent2)
stdMedium2 = np.array(stdMedium2)
stdNoturgent2 = np.array(stdNoturgent2)
ax2.plot(x2, urgent2,'-',color='dodgerblue',label ='Urgent')
ax2.fill_between(x2, urgent2 - stdUrgent2, urgent2 + stdUrgent2,color='dodgerblue', alpha=0.3)
ax2.plot(x2,medium2,'-',color ='orange',label ='Medium')
ax2.fill_between(x2, medium2 - stdMedium2, medium2 + stdMedium2,color='orange', alpha=0.3)
ax2.plot(x2,not_urgent2,'-',color='green',label ='Not-Urgent')
ax2.fill_between(x2, not_urgent2 - stdNoturgent2, not_urgent2 + stdNoturgent2,color='lime', alpha=0.2)
ax2.set_xlabel(r'Population, $n$')
ax2.set_ylabel('Allocated slot preference')
ax2.grid()
# plt.show()
plt.xticks(x2)
plt.tight_layout()
fig.savefig(os.path.join(os.getcwd(), 'scaled.pdf'))