import matplotlib.pyplot as plt
import numpy as np
import csv, os, sys

INPUT_FILE = sys.argv[1]

populationSize = []
not_urgent = []
medium = []
urgent = []
stdNoturgent = []
stdMedium = []
stdUrgent = []

with open(INPUT_FILE, 'r') as csvfile:
	reader = csv.reader(csvfile, delimiter=',')
	next(reader)
	for rows in reader:
		populationSize.append(float(rows[0]))
		not_urgent.append(float(rows[1]))
		medium.append(float(rows[2]))
		urgent.append(float(rows[3]))
		stdNoturgent.append(float(rows[4]))
		stdMedium.append(float(rows[5]))
		stdUrgent.append(float(rows[6]))

fig = plt.figure(figsize=(20,10) )
x = np.array(populationSize)
urgent = np.array(urgent)
medium = np.array(medium)
not_urgent =np.array(not_urgent)
stdUrgent=np.array(stdUrgent)
stdMedium=np.array(stdMedium)
stdNoturgent=np.array(stdNoturgent)
plt.plot(x, urgent,'-',color='dodgerblue',label ='Urgent')
plt.fill_between(x, urgent - stdUrgent, urgent + stdUrgent,color='dodgerblue', alpha=0.3)
plt.plot(x,medium,'-',color ='orange',label ='Medium')
plt.fill_between(x, medium - stdMedium, medium + stdMedium,color='orange', alpha=0.3)
plt.plot(x,not_urgent,'-',color='green',label ='Not-Urgent')
plt.fill_between(x, not_urgent - stdNoturgent, not_urgent + stdNoturgent,color='lime', alpha=0.2)

plt.xlabel('population')
plt.ylabel('slots')
plt.title('population vs preffered slots')
plt.legend(loc ='upper left') 
plt.grid()
plt.show()