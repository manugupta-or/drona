import matplotlib.pyplot as plt
import numpy as np
import csv, os, sys

INPUT_FILE = sys.argv[1]

populationSize = []
not_urgent = []
medium = []
urgent = []
stdNoturgent = []
stdMedium = []
stdUrgent = []
misPriority = []
stdMisPriority = []

with open(INPUT_FILE, 'r') as csvfile:
	reader = csv.reader(csvfile, delimiter=',')
	next(reader)
	for rows in reader:
		populationSize.append(float(rows[0]))
		not_urgent.append(float(rows[1]))
		medium.append(float(rows[2]))
		urgent.append(float(rows[3]))
		stdNoturgent.append(float(rows[4]))
		stdMedium.append(float(rows[5]))
		stdUrgent.append(float(rows[6]))
		misPriority.append(float(rows[7]))
		stdMisPriority.append(float(rows[8]))

fig = plt.figure()
x = np.array(populationSize)
urgent = np.array(urgent)
medium = np.array(medium)
not_urgent =np.array(not_urgent)
stdUrgent=np.array(stdUrgent)
stdMedium=np.array(stdMedium)
stdNoturgent=np.array(stdNoturgent)
misPriority=np.array(misPriority)
stdMisPriority=np.array(stdMisPriority)

plt.plot(x, urgent,'-',color='dodgerblue',label ='Urgent')
plt.fill_between(x, urgent - stdUrgent, urgent + stdUrgent,color='dodgerblue', alpha=0.3)
plt.plot(x,medium,'-',color ='orange',label ='Medium')
plt.fill_between(x, medium - stdMedium, medium + stdMedium,color='orange', alpha=0.3)
plt.plot(x,not_urgent,'-',color='green',label ='Not-Urgent')
plt.fill_between(x, not_urgent - stdNoturgent, not_urgent + stdNoturgent,color='lime', alpha=0.2)

plt.xlabel('population')
plt.ylabel('slots Preference')
plt.title('population vs preffered slots')
plt.legend(loc ='upper left') 
plt.grid()
plt.show()

fig, ax = plt.subplots(figsize=(9,4))
ax.bar(x + 0.00, misPriority ,yerr=stdMisPriority, color = 'green', width = 0.80,label ='misPriority',capsize=1, alpha=0.75)

# ax.legend()

ax.set_xlabel(r'Population, $n$')
ax.set_ylabel('Mispriority')
ax.grid()
plt.xticks(x)
# ax.set_title("misPriority vs population")
plt.show()
fig.savefig(os.path.join(os.getcwd(), 'scaled.pdf'))