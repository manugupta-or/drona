import numpy as np
from gurobipy import *
import random, re, os, time, sys, csv
import multiprocessing as mp
import concurrent.futures
import matplotlib.pyplot as plt

def getMispriority(N, M, slot_cap, allocated_slot_list, urgency_list, priority_matrix):
	result = 0
	for i in range(1, len(N)+1):
		for j in range(i+1, len(N)+1):
			if i > len(M)*slot_cap or j > len(M)*slot_cap:
				continue
			if priority_matrix[i-1][allocated_slot_list[i-1]] < priority_matrix[j-1][allocated_slot_list[j-1]] and urgency_list[i-1] < urgency_list[j-1]:
				result += priority_matrix[j-1][allocated_slot_list[j-1]] - priority_matrix[i-1][allocated_slot_list[i-1]] + urgency_list[j-1] - urgency_list[i-1]
	return result	

def perSampleCompute(argv):
	temp2_not_urgent = []
	temp2_medium = []
	temp2_urgent = []
	temp2_overflow = []

	urgency_list = []
	for _ in argv[0]:
		urgency_list.append(random.choice([argv[4], argv[5], argv[6]]))

	allocated_slot_id = 1
	slot_load = 0
	allocated_slot_list = []
	for i in range(len(argv[0])):
		if allocated_slot_id > len(argv[1]):
			temp2_overflow.append(len(argv[0])-argv[2]*len(argv[1]))
			break
		slot_load += 1
		print(str(urgency_list[i])+" "+str(i)+","+str(allocated_slot_id-1))
		if urgency_list[i] == argv[4]:
			temp2_not_urgent.append(argv[3][i][allocated_slot_id-1])
		elif urgency_list[i] == argv[5]:
			temp2_medium.append(argv[3][i][allocated_slot_id-1])
		elif urgency_list[i] == argv[6]:
			temp2_urgent.append(argv[3][i][allocated_slot_id-1])
		allocated_slot_list.append(allocated_slot_id-1)
		if slot_load == argv[2]:
			allocated_slot_id += 1
			slot_load = 0

	results = getMispriority(argv[0], argv[1], argv[2], allocated_slot_list, urgency_list, argv[3])

	return temp2_not_urgent, temp2_medium, temp2_urgent, temp2_overflow, [results]

def main():
	no_of_slots = int(sys.argv[1])
	slot_cap = int(sys.argv[2])
	percent_bound = int(sys.argv[3])
	delta  = float(sys.argv[4])

	not_urgent_score = int(sys.argv[5])
	medium_score = int(sys.argv[6])
	urgent_score = int(sys.argv[7])

	preference = int(sys.argv[8])
	repeat = int(sys.argv[9])

	urgent = []
	stdUrgent = []
	medium = []
	stdMedium = []
	noturgent = []
	stdNoturgent = []
	populationSize = []	
	overflow = []
	stdOverflow = []
	misPriority = []
	stdMisPriority = []

	M = list(range(1, no_of_slots+1))

	MAX_POPULATION = int(no_of_slots*slot_cap + percent_bound*no_of_slots*slot_cap/100)

	start = time.perf_counter()

	for k in range(2,MAX_POPULATION+1):
		N = list(range(1,k+1))
		rows, cols = (len(N), len(M))
		temp1_not_urgent = []
		temp1_medium = []
		temp1_urgent = []
		temp1_overflow = []
		temp1_result = []
		
		for _ in range(repeat):
			priority_matrix = []

			if preference == 1:
				for i in range(rows):
					priority_matrix.append(list(np.random.permutation(range(1,cols+1))))
			else:
				priority_matrix = [[(i+1) for i in range(cols)] for j in range(rows)]
			print(priority_matrix)

			with concurrent.futures.ProcessPoolExecutor() as executer:
				results = [executer.submit(perSampleCompute,[N, M, slot_cap, priority_matrix, not_urgent_score, medium_score, urgent_score]) for _ in range(10*k)]
				
				for f in concurrent.futures.as_completed(results):
					temp1_not_urgent.extend(f.result()[0])
					temp1_medium.extend(f.result()[1])
					temp1_urgent.extend(f.result()[2])
					temp1_overflow.extend(f.result()[3])
					temp1_result.extend(f.result()[4])

		noturgent.append(np.mean(temp1_not_urgent))
		medium.append(np.mean(temp1_medium))
		urgent.append(np.mean(temp1_urgent))
		stdNoturgent.append(np.std(temp1_not_urgent))
		stdMedium.append(np.std(temp1_medium))
		stdUrgent.append(np.std(temp1_urgent))
		overflow.append(np.mean(temp1_overflow))
		stdOverflow.append(np.std(temp1_overflow))
		misPriority.append(np.mean(temp1_result))
		stdMisPriority.append(np.std(temp1_result))
		populationSize.append(k)

	end = time.perf_counter()

	print("MAX_POPULATION: "+str(MAX_POPULATION))
	print(f'Time Taken for computation of {MAX_POPULATION} : {end-start} second(s)')

	fig = plt.figure()
	x = np.array(populationSize)
	urgent = np.array(urgent)
	medium = np.array(medium)
	noturgent =np.array(noturgent)
	stdUrgent=np.array(stdUrgent)
	stdMedium=np.array(stdMedium)
	stdNoturgent=np.array(stdNoturgent)
	overflow=np.array(overflow)
	stdOverflow=np.array(stdOverflow)
	plt.plot(x, urgent,'-',color='dodgerblue',label ='Urgent')
	plt.fill_between(x, urgent - stdUrgent, urgent + stdUrgent,color='dodgerblue', alpha=0.3)
	plt.plot(x,medium,'-',color ='orange',label ='Medium')
	plt.fill_between(x, medium - stdMedium, medium + stdMedium,color='orange', alpha=0.3)
	plt.plot(x,noturgent,'-',color='green',label ='Not-Urgent')
	plt.fill_between(x, noturgent - stdNoturgent, noturgent + stdNoturgent,color='lime', alpha=0.2)
	# plt.plot(x,overflow,'-',color='red',label ='overflow') # comes linear as all are dropped off after the slots are full 
	# plt.fill_between(x, overflow - stdOverflow, overflow + stdOverflow,color='red', alpha=0.2)
	plt.xticks(x)
	plt.xlabel(r'Population, $n$')
	plt.ylabel('Allocated slot preference')
	plt.title('population vs preffered slots')
	plt.legend(loc ='upper left') 
	plt.grid()
	# plt.show()
	fig.savefig(os.path.join(os.getcwd(), 'output/plots/img1_'+str(len(M))+"_"+str(MAX_POPULATION)+"_"+str(preference)))

	fig, ax = plt.subplots()
	ax.bar(x + 0.00, misPriority ,yerr=stdMisPriority, color = 'green', width = 0.25,label ='misPriority',capsize=1)

	ax.legend()
	ax.grid()
	plt.xticks(x)
	ax.set_xlabel(r'Population, $n$')
	ax.set_ylabel('Mispriority')
	ax.set_title("Mispriority vs population")
	# plt.show()
	fig.savefig(os.path.join(os.getcwd(), 'output/plots/img2_'+str(len(M))+"_"+str(MAX_POPULATION)+"_"+str(preference)))

	with open(os.path.join(os.getcwd(), 'output/csv/data_'+str(len(M))+"_"+str(MAX_POPULATION)+"_"+str(preference)+".csv"), mode ='w') as csvfile:
		fieldName = ['populationSize','not_urgent', 'medium', 'urgent', 'stdNoturgent', 'stdMedium', 'stdUrgent', 'misPriority', 'stdMisPriority']
		writer = csv.DictWriter(csvfile, fieldnames = fieldName)

		writer.writeheader()
		for i in range(len(x)):
			writer.writerow({
				'populationSize' : x[i], 
				'not_urgent': noturgent[i], 
				'medium': medium[i], 
				'urgent': urgent[i], 
				'stdNoturgent': stdNoturgent[i], 
				'stdMedium': stdMedium[i], 
				'stdUrgent': stdUrgent[i],
				'misPriority' : misPriority[i],
				'stdMisPriority' : stdMisPriority[i]
				})

if __name__ == '__main__':
	main()
