import matplotlib.pyplot as plt
import numpy as np
import csv, os, sys, re

INPUT_FILE1 = sys.argv[1]
INPUT_FILE2 = sys.argv[2]

slot_cap1 = int(INPUT_FILE1.split('_')[1])
len_m1 = int(INPUT_FILE1.split('_')[3])
X1 = [] 
final_allocations_mean1 = [] 
final_pref_allocations_mean1 = []
non_allocated_mean1 = []
final_allocations_std1 = []
final_pref_allocations_std1 = []
non_allocated_std1 = []

slot_cap2 = int(INPUT_FILE2.split('_')[1])
len_m2 = int(INPUT_FILE2.split('_')[3])
X2 = [] 
final_allocations_mean2 = [] 
final_pref_allocations_mean2 = []
non_allocated_mean2 = []
final_allocations_std2 = []
final_pref_allocations_std2 = []
non_allocated_std2 = []

with open(INPUT_FILE1, 'r') as csvfile:
	reader = csv.reader(csvfile, delimiter=',')
	next(reader)
	for rows in reader:
		X1.append(int(rows[0])) 
		final_allocations_mean1.append(float(rows[1])) 
		final_pref_allocations_mean1.append(float(rows[2]))
		non_allocated_mean1.append(float(rows[3]))
		final_allocations_std1.append(float(rows[4]))
		final_pref_allocations_std1.append(float(rows[5]))
		non_allocated_std1.append(float(rows[6]))

with open(INPUT_FILE2, 'r') as csvfile:
	reader = csv.reader(csvfile, delimiter=',')
	next(reader)
	for rows in reader:
		X2.append(int(rows[0])) 
		final_allocations_mean2.append(float(rows[1])) 
		final_pref_allocations_mean2.append(float(rows[2]))
		non_allocated_mean2.append(float(rows[3]))
		final_allocations_std2.append(float(rows[4]))
		final_pref_allocations_std2.append(float(rows[5]))
		non_allocated_std2.append(float(rows[6]))

X1 = np.array(X1) 
final_allocations_mean1 = np.array(final_allocations_mean1) 
final_pref_allocations_mean1 = np.array(final_pref_allocations_mean1)
non_allocated_mean1 = np.array(non_allocated_mean1)
final_allocations_std1 = np.array(final_allocations_std1)
final_pref_allocations_std1 = np.array(final_pref_allocations_std1)
non_allocated_std1 = np.array(non_allocated_std1)

X2 = np.array(X2) 
final_allocations_mean2 = np.array(final_allocations_mean2) 
final_pref_allocations_mean2 = np.array(final_pref_allocations_mean2)
non_allocated_mean2 = np.array(non_allocated_mean2)
final_allocations_std2 = np.array(final_allocations_std2)
final_pref_allocations_std2 = np.array(final_pref_allocations_std2)
non_allocated_std2 = np.array(non_allocated_std2)

fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True)
ax1.bar(X1 , final_allocations_mean1,yerr=final_allocations_std1 , color = 'gold',width=0.4,label ='IMPPreSS population')
ax1.bar(X1+0.4 , final_pref_allocations_mean1 , yerr= final_pref_allocations_std1 , color = 'teal',width=0.4,label ='Current population')
ax1.bar(X1+0.8 , non_allocated_mean1 , yerr= non_allocated_std1 , color = 'coral',width=0.4,label ='Non allocated')
ax1.set_ylabel('Population')
# ax1.set_title("Slot capacity : "+str(slot_cap1))
ax1.hlines(slot_cap1,xmin=7,xmax =len_m1+8,linestyle='dashed', color='red',label='Slot capacity',)
ax1.grid()
ax1.legend(loc='upper left')

ax2.bar(X2 , final_allocations_mean2,yerr=final_allocations_std2 , color = 'gold',width=0.4,label ='IMPPreSS population')
ax2.bar(X2+0.4 , final_pref_allocations_mean2 , yerr= final_pref_allocations_std2 , color = 'teal',width=0.4,label ='Current population')
ax2.bar(X2+0.8 , non_allocated_mean2 , yerr= non_allocated_std2 , color = 'coral',width=0.4,label ='Non allocated')
ax2.set_ylabel('Population')
# ax2.set_title("Slot capacity : "+str(slot_cap2))
ax2.hlines(slot_cap2,xmin=7,xmax =len_m2+8,linestyle='dashed', color='red',label='Slot capacity',)
ax2.grid()
# ax2.legend(loc='upper left')

plt.xlabel('Hourly slots of the day')
plt.xticks(X2+0.2,X2)
plt.tight_layout()
# plt.show()

fig.savefig(os.path.join(os.getcwd(), 'plotter.pdf'))