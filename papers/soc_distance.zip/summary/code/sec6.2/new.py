new = {1:2,2:3,3:4}
p=[]
for a,b in new.items():
    if (a<3):
        p.append(a)
for i in p:
    del new[i]

print(new)