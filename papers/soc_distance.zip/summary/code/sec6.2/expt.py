import numpy as np
from gurobipy import *
import random, re, os, time, sys,csv
import multiprocessing as mp
import concurrent.futures
import matplotlib.pyplot as plt
import matplotlib
from data import *
dictionary_len=[]
def print_sol(model):
    for var in model.getVars():
        if(abs(var.x)>1e-6):
            print('{0}:{1}'.format(var.varName,var.x))
            
    #print('Allocation score :{0}'.format(model.objVal))
    return None


def optimizer(urgencyList,priority_MATRIX,N_agents, LOWER_URGENCY,MID_URGENCY,HIGHER_URGENCY ):
        
        combinations,ms = multidict({
            (y,x):(delta**(priority_MATRIX[y-1][x-1]-1)) * urgencyList[y-1] for x in range(1,len(M)+1) for y in range(1,len(N_agents)+1)
            })
        valuation_matrix = ms.copy()
        
        model = Model('allocator')
        variables = model.addVars(combinations,lb=0,vtype=GRB.BINARY,name='assign')
        model.update()
        slots = model.addConstrs((variables.sum('*',j)<= slot_cap for j in M),'slots')
        agents = model.addConstrs((variables.sum(i,'*')<=1 for i in N_agents),'agents')
        model.setObjective(variables.prod(ms),GRB.MAXIMIZE)
        model.write('mark0.lp')
        model.optimize()

        print("Model Status "+str(model.Status))
        print("===Optimal Allotment===")
        print_sol(model)
        allocation_map={}
        for var in model.getVars():
                assign = re.search(r"\[([A-Za-z,0-9_]+)\]", var.varName)
                assign = assign.group(1)
                assign = assign.split(',')
                if(abs(var.x)>1e-6):
                    
                    allocation_map[int(assign[0])]=int(assign[1])
                   
                    if(urgencylist[int(assign[0])-1]==LOWER_URGENCY):
                        tempAvgNoturgent.append(int(assign[1]))
                        tempAvgNoturgent_population.append(int(assign[1]))
                    if(urgencylist[int(assign[0])-1]==MID_URGENCY):
                        tempAvgMid.append(int(assign[1]))
                        tempAvgMid_population.append(int(assign[1]))
                    if(urgencylist[int(assign[0])-1]==HIGHER_URGENCY):
                        tempAvgUrgent.append(int(assign[1]))
                        tempAvgUrgent_population.append(int(assign[1]))

        return valuation_matrix ,allocation_map , model.objVal


no_of_slots = int(sys.argv[1])
percent_bound = int(sys.argv[3])
LOWER_URGENCY = int(sys.argv[5])
MID_URGENCY = int(sys.argv[6])
HIGHER_URGENCY = int(sys.argv[7])
start_date = int(sys.argv[8])
M = list(range(1, no_of_slots+1)) #number of slots

urgent=[]
stdUrgent=[]
medium=[]
stdMedium=[]
noturgent=[]
stdNoturgent=[]
avgUrgency=[]
graph_obj = dict()
populationSize = []
non_allocated=[]

waitUrgent=[]
waitMedium=[]
waitNoturgent=[]
waitStdUrgent=[]
waitStdMedium=[]
waitStdNoturgent=[]

utilityUrgent = []
utilityMedium = []
utilityNoturgent = []
stdUtilityUrgent = []
stdUtilityMedium = []
stdUtilityNoturgent = []

list_unallocated_agents={}
empty_days={}
delta = float(sys.argv[4])
slot_cap= int(sys.argv[2])

MAX_POPULATION = int(len(M)*slot_cap + percent_bound*len(M)*slot_cap/100) 

start = time.perf_counter()
final_pref_allocations=[[] for _ in range(len(M))]
final_allocations=[[] for _ in range(len(M))]
distribution=[]
distribution_temp = data()
for d in range(len(distribution_temp)):
    temp = []
    for t in range(0,len(distribution_temp[d]),2):
        temp.append(distribution_temp[d][t] + distribution_temp[d][t+1])
    distribution.append(temp)
#print(distribution)
#print(len(distribution))

days_for_allocation=[]
if(start_date == 0):
    days_for_allocation=[i for i in range(0,len(distribution))]
else:
    i=start_date-1
    #while(i <= len(distribution)):
    #    days_for_allocation.append(i)
    #    i=i+7
    days_for_allocation.append(i)
# Loop starts with k as iter. till MAX_POPULATION
#days_for_allocation=[4,5,6]
for k in days_for_allocation:
    
    # If for a single k its been checked we can set MAX_POPULATION = MIN_POPULATION+1 in range
    # i.e. k = MAX_POPULATION and uncomment the desried code.
    population = sum(distribution[k])
    preferred_slot_arrangement=[0 for i in range(0,len(M))]
    slot_fillings=[0 for _ in range(0,len(M))]
    
    number_samples = 1
    # Denote temp. for population size vs slot iteration
    tempAvgUrgent_population=[]
    tempAvgMid_population=[]
    tempAvgNoturgent_population=[]
    tempTimeUrgent=[]
    tempTimeMedium=[]
    tempTimeNoturgent=[]

    tempUtilityUrgent=[]
    tempUtilityMedium=[]
    tempUtilityNoturgent=[]
    
    rows, cols = (population , len(M)) 
    priority_matrix = []

    if(population==0):
        urgent.append(0)
        stdUrgent.append(0)
        medium.append(0)
        stdMedium.append(0)
        noturgent.append(0)
        stdNoturgent.append(0)
        populationSize.append(0)
        #Finding avg time from all samples:
        waitUrgent.append(0)
        waitMedium.append(0)
        waitNoturgent.append(0)
        waitStdUrgent.append(0)
        waitStdMedium.append(0)
        waitStdNoturgent.append(0)
        #Find Utility
        utilityUrgent.append(0) 
        utilityMedium.append(0)
        utilityNoturgent.append(0)
        stdUtilityUrgent.append(0)
        stdUtilityMedium.append(0)
        stdUtilityNoturgent.append(0)
        empty_days[int(k)]=1
        continue
    ####################################################check for previous day unallocated#########################
    final_non_allocated_index=[]
    next_day_passing_list_agents=[]
    next_day_passing_urgency=[]
    gap=0
    if k-1 in empty_days.keys():
        gap +=1
    if k-2 in empty_days.keys():
        gap +=1
    if k-3 in empty_days.keys():
        gap +=1    
    for number, value in list_unallocated_agents.items(): 
        day,urgency = value.split('-')
        if(int(day)<= k-2-gap ):
            final_non_allocated_index.append(number)
    for key in final_non_allocated_index:
        del list_unallocated_agents[key]
    for number, value in list_unallocated_agents.items(): 
        next_day_passing_list_agents.append(value)
        day,urgency_ = value.split('-')
        next_day_passing_urgency.append(3)
    list_unallocated_agents={}
    ################################################################################################################
    N = list(range(1, population+1+len(next_day_passing_list_agents)))#population base : with range(1,k) with k as iterator till MAX_POPULATION

    # FOR EQUAL PRIORITY FOR ALL PEOPLE
    #priority_matrix = [[(i+1) for i in range(cols)] for j in range(rows)] 
    
   #  FOR PRIORITY MANNUAL
   #  priority_matrix = [    
   #      [1,2,3],
   #      [1,2,3],
   #      [2,1,3],
   #      [1,3,2],
   #      [1,2,3],
   #      [3,1,2],
   #      [2,1,3],
   #      [2,1,3],
   #      [2,3,1],
   #      [2,3,1],
   #      [1,2,3],
   #      [1,2,3]
   #  ]
    
    # FOR RANDOM URGENCY OF EACH AGENT WITH CHANGING POPULATION
    urgencylist = []
        
    for i in range(rows):
            n = random.choice([LOWER_URGENCY,MID_URGENCY,HIGHER_URGENCY])
            urgencylist.append(n)
    
    urgencylist.extend(next_day_passing_urgency)

    preferences_sorted_index = np.argsort(-1*np.array(distribution[k]))
    preferences = [0 for _ in range(len(distribution[k]))]
    for i in range(len(distribution[k])):
        preferences[preferences_sorted_index[i]] = i+1
    #print(preferences)

    for l in range(1,rows+1):
        list_unallocated_agents[l]=(str(k+1)+"-"+str(urgencylist[l-1]))
        priority_matrix.append(list(preferences))
    for l in range(0,len(next_day_passing_list_agents)):
        list_unallocated_agents[rows+1+l]=(next_day_passing_list_agents[l])
        priority_matrix.append(list(preferences))
    print(list_unallocated_agents)

 

    #for _ in range(rows):
    #    priority_matrix.append(list(np.random.permutation(range(1,cols+1))))

    ####################################################synthetic data####################################################
    #mu, sigma = cols/2, 1 # mean and standard deviation
    #distribution = np.random.normal(mu, sigma, rows)
    #distribution = list(np.round(distribution))
    #distribution = np.clip(distribution, 0, cols)
    #print(distribution)
    #for x in distribution:
    #    permutation = np.random.permutation(range(1,cols+1))
    #    permutation = list(np.delete(permutation, np.argwhere(permutation == int(1))))
    #    #print(type(permutation))
    #    permutation.insert(int(x),1)
    #    #print(permutation)
    #    priority_matrix.append(permutation)          
    #print(priority_matrix)
    ####################################################synthetic data####################################################

    #for p in range(0,population):
    #    print(priority_matrix[p][0])
    #    preferred_slot_arrangement[priority_matrix[p].index(1)] += 1
    #print(priority_matrix)


    for iteration in range(number_samples): # iteration for each n. Taken as sample for each n
        print("============================= iteration id:"+str(k)+"============================")
        print(population)
        tempAvgUrgent=[]
        tempAvgMid=[]
        tempAvgNoturgent=[]
        print(len(urgencylist))
        print(len(priority_matrix))
        valuation_matrix,allocation_map,valuation_sum = optimizer(urgencylist,priority_matrix, N, LOWER_URGENCY,MID_URGENCY,HIGHER_URGENCY)
        print(len(allocation_map))
        print(allocation_map)
        dictionary_len.append(len(allocation_map))
        #print(valuation_matrix)
        for key in allocation_map:
            slot_fillings[allocation_map[key]-1] +=  1 
            del list_unallocated_agents[key] 
        print(len(list_unallocated_agents))
        #print(list_unallocated_agents)
        print('******************************')
        #print(urgencylist)
        '''
        ############################# VCG #############################
        for index in range(1,len(N)+1):
            if index in allocation_map: #there is chance agrent might not be allocated
                valuation_sum_agent = valuation_sum - valuation_matrix[(index,allocation_map[index])]
            else:
                continue
            urgency_of_agent = urgencylist[index-1]
            
            urgencylist_without_agent = urgencylist[:]
            priority_matrix_without_agent  = priority_matrix[:]
            N_without_agent =list(range(1, population))
            
            del urgencylist_without_agent[index-1]
            del priority_matrix_without_agent[index-1]
           
            print(urgencylist_without_agent)

            valuation_matrix_without_agent , allocation_map_without_agent ,valuation_sum_without_agent = optimizer(urgencylist_without_agent,priority_matrix_without_agent,N_without_agent, LOWER_URGENCY,MID_URGENCY,HIGHER_URGENCY )

            VCG = valuation_sum_without_agent - valuation_sum_agent
            
            if(urgency_of_agent == LOWER_URGENCY):
                tempTimeNoturgent.append(VCG)
                tempUtilityNoturgent.append(valuation_matrix[(index,allocation_map[index])]-VCG)
            elif(urgency_of_agent == MID_URGENCY):
                tempTimeMedium.append(VCG)
                tempUtilityMedium.append(valuation_matrix[(index,allocation_map[index])]-VCG)
            elif(urgency_of_agent == HIGHER_URGENCY):
                tempTimeUrgent.append(VCG)
                tempUtilityUrgent.append(valuation_matrix[(index,allocation_map[index])]-VCG)
                                      
            print('VCG for agent'+str(index)+" ========  "+str(VCG))
            print('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
        ##############################################################
        '''
        # if iterated over a particular population size and for plotting avg_urgency(of that len(N) population) vs avg_slot 
        # alloted to each class.    
#         graph_obj.update({np.mean(urgencylist):(np.mean(tempAvgUrgent),np.std(tempAvgUrgent),
#                                               np.mean(tempAvgMid),np.std(tempAvgMid),
#     
#                                         np.mean(tempAvgNoturgent),np.std(tempAvgNoturgent))})
    #fill slot matrix
    non_allocated.append(len(final_non_allocated_index))
    for i in range(len(M)):
        final_pref_allocations[i].extend([distribution[k][i]])
        final_allocations[i].extend([slot_fillings[i]])
    # If changing population no. this is needed to be kept uncommented else commented.
    urgent.append(np.mean(tempAvgUrgent_population))
    stdUrgent.append(np.std(tempAvgUrgent_population))
    medium.append(np.mean(tempAvgMid_population))
    stdMedium.append(np.std(tempAvgMid_population))
    noturgent.append(np.mean(tempAvgNoturgent_population))
    stdNoturgent.append(np.std(tempAvgNoturgent_population))
    populationSize.append(k)
    #Finding avg time from all samples:
    waitUrgent.append(np.mean(tempTimeUrgent))
    waitMedium.append(np.mean(tempTimeMedium))
    waitNoturgent.append(np.mean(tempTimeNoturgent))
    waitStdUrgent.append(np.std(tempTimeUrgent))
    waitStdMedium.append(np.std(tempTimeMedium))
    waitStdNoturgent.append(np.std(tempTimeNoturgent))
    #Find Utility
    utilityUrgent.append(np.mean(tempUtilityUrgent)) 
    utilityMedium.append(np.mean(tempUtilityMedium))
    utilityNoturgent.append(np.mean(tempUtilityNoturgent))
    stdUtilityUrgent.append(np.std(tempUtilityUrgent))
    stdUtilityMedium.append(np.std(tempUtilityMedium))
    stdUtilityNoturgent.append(np.std(tempUtilityNoturgent))
    #Slot arrangements
    #slot_fillings[:] = [x / number_samples for x in slot_fillings]

end = time.perf_counter()

print("\nMAX_POPULATION: "+str(MAX_POPULATION))
print(f'Time Taken for computation of {population} : {end-start} second(s)')

waitNoturgent= np.array(waitNoturgent)
waitMedium = np.array(waitMedium)
waitUrgent = np.array(waitUrgent) 

print(urgent)
print(waitUrgent)
print(utilityMedium)
X = np.arange( 0 , len(days_for_allocation))
fig, ax = plt.subplots()

ax.bar(X + 0.00, noturgent,yerr=stdNoturgent, color = 'green', width = 0.25,label ='Not-Urgent',capsize=1)
ax.bar(X + 0.25, medium,yerr=stdMedium , color = 'orange', width = 0.25,label ='Medium',capsize=1)
ax.bar(X + 0.50, urgent, yerr=stdUrgent ,color = 'dodgerblue', width = 0.25,label ='Urgent',capsize=1)

ax.bar(X + 0.00, waitNoturgent,yerr=waitStdNoturgent,bottom = noturgent,  color = 'palegreen', width = 0.25,label ='Wait-Not-Urgent',capsize=1)
ax.bar(X + 0.25, waitMedium,yerr=waitStdMedium ,bottom = medium, color = 'moccasin', width = 0.25,label ='Wait-Medium',capsize=1)
ax.bar(X + 0.50, waitUrgent, yerr=waitStdUrgent,bottom = urgent ,color = 'mediumturquoise', width = 0.25,label ='Wait-Urgent',capsize=1)


ax.bar(X + 0.00, waitNoturgent,yerr=waitStdNoturgent,bottom = noturgent,  color = 'palegreen', width = 0.25,label ='Not-Urgent',capsize=1)
ax.bar(X + 0.25, waitMedium,yerr=waitStdMedium ,bottom = medium, color = 'moccasin', width = 0.25,label ='Medium',capsize=1)
ax.bar(X + 0.50, waitUrgent, yerr=waitStdUrgent,bottom = urgent ,color = 'mediumturquoise', width = 0.25,label ='Urgent',capsize=1)

plt.legend(loc ='upper left') 
ax.set_xlabel('Day')
ax.set_ylabel('VCG Payment & Allocated Slot')
ax.set_title("Wait time for slot And Allocated Slot vs Day")
fig.savefig(os.path.join(os.getcwd(), 'output/img4_1_'+str(len(M))+"_"+str(population)))


fig, ax = plt.subplots()
ax.bar(X + 0.00, noturgent,yerr=stdNoturgent, color = 'green', width = 0.25,label ='Not-Urgent',capsize=1)
ax.bar(X + 0.25, medium,yerr=stdMedium , color = 'orange', width = 0.25,label ='Medium',capsize=1)
ax.bar(X + 0.50, urgent, yerr=stdUrgent ,color = 'dodgerblue', width = 0.25,label ='Urgent',capsize=1)
plt.legend(loc ='upper left') 
ax.set_xlabel('Day')
ax.set_ylabel('Allocated slot')
ax.set_title("allocated Slot vs Day")
fig.savefig(os.path.join(os.getcwd(), 'output/img4_2_'+str(len(M))+"_"+str(population)))

fig, ax = plt.subplots()
ax.bar(X + 0.00, waitNoturgent,yerr=waitStdNoturgent,  color = 'palegreen', width = 0.25,label ='Wait-Not-Urgent',capsize=1)
ax.bar(X + 0.25, waitMedium,yerr=waitStdMedium , color = 'moccasin', width = 0.25,label ='Wait-Medium',capsize=1)
ax.bar(X + 0.50, waitUrgent, yerr=waitStdUrgent,color = 'mediumturquoise', width = 0.25,label ='Wait-Urgent',capsize=1)
plt.legend(loc ='upper left') 
ax.set_xlabel('Day')
ax.set_ylabel('VCG payment')
ax.set_title("VCG vs Day")
fig.savefig(os.path.join(os.getcwd(), 'output/img4_3_'+str(len(M))+"_"+str(population)))
# For Wait time vs population
# fig, ax = plt.subplots()
# X = np.arange(2 ,MAX_POPULATION+1)
# ax.bar(X, waitNoturgent, width=0.25, yerr= waitStdNoturgent , label='Not-Urgent',color = 'green',capsize=3)
# ax.bar(X, waitMedium , width=0.25, yerr= waitStdMedium , bottom=waitNoturgent,label ='Medium', color = 'orange',capsize=3)
# ax.bar(X, waitUrgent , width=0.25, yerr= waitStdUrgent , bottom= waitMedium +waitNoturgent,label ='Urgent',color = 'dodgerblue',capsize=3)

# ax.legend()

# ax.set_xlabel('populationSize')
# ax.set_ylabel('VCG Payment')
# ax.set_title("Wait time vs populationSize")

# fig.savefig(os.path.join(os.getcwd(), 'output/img3_2_'+str(len(M))+"_"+str(MAX_POPULATION)))

fig, ax = plt.subplots()
ax.bar(X + 0.00, utilityNoturgent ,yerr=stdUtilityUrgent, color = 'green', width = 0.25,label ='Not-Urgent',capsize=1)
ax.bar(X + 0.25, utilityMedium ,yerr=stdUtilityMedium , color = 'orange', width = 0.25,label ='Medium',capsize=1)
ax.bar(X + 0.50, utilityUrgent , yerr=stdUtilityNoturgent ,color = 'dodgerblue', width = 0.25,label ='Urgent',capsize=1)

ax.legend()

ax.set_xlabel('Day')
ax.set_ylabel('Utility')
ax.set_title("Utility vs Day")

fig.savefig(os.path.join(os.getcwd(), 'output/img4_4_'+str(len(M))+"_"+str(population)))

final_pref_allocations_mean = [np.mean(final_pref_allocations[i]) for i in range(len(M))]
final_pref_allocations_std = [np.std(final_pref_allocations[i]) for i in range(len(M))]
final_allocations_mean = [np.mean(final_allocations[i]) for i in range(len(M))]
final_allocations_std = [np.std(final_allocations[i]) for i in range(len(M))]
non_allocated_mean = [0 for i in range(len(M))]
non_allocated_std = [0 for i in range(len(M))]
non_allocated_mean.append(np.mean(non_allocated))
non_allocated_std.append(np.std(non_allocated))
final_pref_allocations_mean.append(0)
final_pref_allocations_std.append(0)
final_allocations_mean.append(0)
final_allocations_std.append(0)

fig, ax = plt.subplots()
#ax.figure((10,20))
X = np.arange(7,len(M)+8)
print(len(slot_fillings))
print(len(X))
print(len(distribution[0]))
print(final_allocations)
print(dictionary_len)
ax.bar(X , final_allocations_mean,yerr=final_allocations_std , color = 'gold',width=0.4,label ='IMPPreSS population')
ax.bar(X+0.4 , final_pref_allocations_mean , yerr= final_pref_allocations_std , color = 'teal',width=0.4,label ='Current population')
ax.bar(X+0.8 , non_allocated_mean , yerr= non_allocated_std , color = 'coral',width=0.4,label ='Non allocated')
plt.xlabel('Hourly slots of the day')
ax.set_ylabel('Population')
plt.xticks(X+0.2,X)
plt.tight_layout()
#ax.set_title("Population vs Slots ")
ax.hlines(slot_cap,xmin=7,xmax =len(M)+8,linestyle='dashed', color='red',label='Slot capacity',)
ax.grid()
ax.legend(loc='upper left')

fig.savefig(os.path.join(os.getcwd(), 'output/img4_7_'+str(len(M))+"_"+str(population))+'.pdf')

with open(os.path.join(os.getcwd(), 'output/csv/tmp2/data1_'+str(slot_cap)+"_"+str(len(N))+"_"+str(len(M))+"_"+str(population)+".csv"), mode ='w') as csvfile:
        fieldName = ['Slot','IMPPreSS_population','Current_population','Non_allocated','final_allocations_std','final_pref_allocations_std','non_allocated_std']
        writer = csv.DictWriter(csvfile, fieldnames = fieldName)

        writer.writeheader()
        for i in range(len(X)):
            writer.writerow({
                'Slot': X[i],
                'IMPPreSS_population' : final_allocations_mean[i], 
                'Current_population' : final_pref_allocations_mean[i],
                'Non_allocated' : non_allocated_mean[i],
                'final_allocations_std' : final_allocations_std[i],
                'final_pref_allocations_std' : final_pref_allocations_std[i],
                'non_allocated_std' : non_allocated_std[i]
                })



